﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using net_crud.Controllers;
using net_crud.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace net_crud.Tests
{
    public class EmployeeServiceTest
    {
        private readonly EmployeeController _controller;
        private readonly Mock<EmployeeContext> _contextMock;
        private readonly Mock<DbSet<Employee>> _dbSetMock;

        public EmployeeServiceTest()
        {
            _contextMock = new Mock<EmployeeContext>();
            _dbSetMock = new Mock<DbSet<Employee>>();

            var employeeData = new List<Employee>
            {
                new Employee { id = "A001", name = "John Doe", birthDate = new DateTime(1990, 1, 1), gender = 1 },
                new Employee { id = "A002", name = "Jane Doe", birthDate = new DateTime(1992, 2, 2), gender = 2 }
            }.AsQueryable();

            _dbSetMock.As<IQueryable<Employee>>().Setup(m => m.Provider).Returns(employeeData.Provider);
            _dbSetMock.As<IQueryable<Employee>>().Setup(m => m.Expression).Returns(employeeData.Expression);
            _dbSetMock.As<IQueryable<Employee>>().Setup(m => m.ElementType).Returns(employeeData.ElementType);
            _dbSetMock.As<IQueryable<Employee>>().Setup(m => m.GetEnumerator()).Returns(employeeData.GetEnumerator());

            // Setup context to return mock DbSet
            _contextMock.Setup(c => c.Set<Employee>()).Returns(_dbSetMock.Object);

            _controller = new EmployeeController(_contextMock.Object);
        }


        [Fact]
        public async Task GetEmployees_ReturnsAllEmployees()
        {
            // Act
            var result = await _controller.GetEmployees();

            // Assert
            var actionResult = Assert.IsType<ActionResult<IEnumerable<Employee>>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            var returnValue = Assert.IsType<List<Employee>>(okResult.Value);

            Assert.Equal(2, returnValue.Count);
        }

        [Fact]
        public async Task AddEmployee_ReturnsConflictForDuplicateId()
        {
            // Arrange
            var newEmployee = new Employee {id = "A001", name = "Duplicate John", birthDate = new DateTime(1991, 1, 1), gender = 1 };

            // Act
            var result = await _controller.PostEmployee(newEmployee);

            // Assert
            var actionResult = Assert.IsType<ConflictResult>(result.Result);
        }

        [Fact]
        public async Task AddEmployee_AddsNewEmployee()
        {
            // Arrange
            var newEmployee = new Employee {id = "A003", name = "New Employee", birthDate = new DateTime(1993, 3, 3), gender = 3 };

            /*_dbSetMock.Setup(m => m.AddAsync(It.IsAny<Employee>(), default)).ReturnsAsync(() => (new Employee(), new object()));
            _contextMock.Setup(m => m.SaveChangesAsync(default)).ReturnsAsync(1);*/

            _dbSetMock.Verify(m => m.AddAsync(It.IsAny<Employee>(), default), Times.Once());
            _contextMock.Verify(m => m.SaveChangesAsync(default), Times.Once());


            // Act
            var result = await _controller.PostEmployee(newEmployee);

            // Assert
            _dbSetMock.Verify(m => m.AddAsync(It.IsAny<Employee>(), default), Times.Once());
            _contextMock.Verify(m => m.SaveChangesAsync(default), Times.Once());

            var actionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
            var returnValue = Assert.IsType<Employee>(actionResult.Value);
            Assert.Equal(newEmployee.id, returnValue.id);
        }
    }
}
