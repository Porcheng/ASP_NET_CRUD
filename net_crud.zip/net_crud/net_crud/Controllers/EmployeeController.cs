﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using net_crud.Models;

namespace net_crud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeContext _employeeContext;
        public EmployeeController(EmployeeContext employeeContext) { 
            _employeeContext = employeeContext;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        {
            if (_employeeContext.Employees == null) 
            { return NotFound();}
            return await _employeeContext.Employees.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetEmployee(string id)
        {
            if (_employeeContext.Employees == null)
            { return NotFound(); }
            var employee = await _employeeContext.Employees.FindAsync(id);
            if(employee == null)
            {
                return NotFound();
            }
            return employee;
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> PostEmployee(Employee employee)
        {
            try { 
                _employeeContext.Employees.Add(employee); 
                await _employeeContext.SaveChangesAsync();
                return CreatedAtAction(nameof(GetEmployee), new { id = employee.id }, employee);
            }
            catch (DbUpdateException ex)
            {
                if (ex.InnerException is SqlException sqlEx && sqlEx.Number == 2627) // 2627 is the error number for primary key violation
                {
                    return Conflict("Employee with the same ID already exists."); // HTTP 409 Conflict
                }
                else
                {
                    // Handle other database or unexpected errors
                    return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while saving the entity changes.");
                }
            }   
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> PutEmployee(string id, Employee employee)
        {
            if(id != employee.id)
            {
                return BadRequest();
            }
            _employeeContext.Entry(employee).State=EntityState.Modified;

            try
            {
                await _employeeContext.SaveChangesAsync();
            }catch(DbUpdateConcurrencyException)
            {
                throw;
            }
            return Ok();
        }

        public class EmployeeSearchCriteria
        {
            public string Id { get; set; }
           // public string Name { get; set; }
            public int Gender { get; set; }
            public DateTime? FromDate { get; set; }
            public DateTime? ToDate { get; set; }
        }

        /*[HttpGet("search")]
        public async Task<ActionResult<IEnumerable<Employee>>> SearchEmployees([FromQuery] EmployeeSearchCriteria criteria)
        {
            // Check if no criteria are provided at all

            var query = _employeeContext.Employees.AsQueryable();

            // Filter by ID if provided
            if (!string.IsNullOrEmpty(criteria.Id))
            {
                query = query.Where(e => e.id == criteria.Id);
            }

            // Filter by Gender if provided
            if (!(criteria.Gender != 0))
            {
                query = query.Where(e => e.gender == criteria.Gender);
            }

            // Filter by FromDate and ToDate range if provided
            if (criteria.FromDate.HasValue)
            {
                query = query.Where(e => e.birthDate >= criteria.FromDate.Value);
            }

            if (criteria.ToDate.HasValue)
            {
                query = query.Where(e => e.birthDate <= criteria.ToDate.Value);
            }

            var employees = await query.ToListAsync();

            if (employees == null || employees.Count == 0)
            {
                return NotFound();
            }

            return employees;
        }
*/
        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<Employee>>> SearchEmployees(
    [FromQuery(Name = "id")] string? id,
    [FromQuery(Name = "gender")] int? gender,
    [FromQuery(Name = "fromDate")] DateTime? fromDate,
    [FromQuery(Name = "toDate")] DateTime? toDate)
        {
            if (_employeeContext.Employees == null)
            {
                return NotFound();
            }

            var query = _employeeContext.Employees.AsQueryable();

            // Filter by ID if provided
            if (!string.IsNullOrEmpty(id))
            {
                query = query.Where(e => e.id == id);
            }

            // Filter by Gender if provided
            if (gender.HasValue && gender != 0)
            {
                query = query.Where(e => e.gender == gender);
            }

            // Filter by BirthDate range if both fromDate and toDate are provided
            if (fromDate.HasValue && toDate.HasValue)
            {
                query = query.Where(e => e.birthDate >= fromDate && e.birthDate <= toDate);
            }
            else if (fromDate.HasValue)
            {
                query = query.Where(e => e.birthDate >= fromDate);
            }
            else if (toDate.HasValue)
            {
                query = query.Where(e => e.birthDate <= toDate);
            }

            var employees = await query.ToListAsync();

            if (employees == null || employees.Count == 0)
            {
                return NotFound();
            }

            return employees;
        }


        [HttpDelete]
        public async Task<ActionResult> DeleteEmployee(string id)
        {
            if(_employeeContext.Employees == null)
            {
                return NotFound();
            }
            var employee = await _employeeContext.Employees.FindAsync(id);
            if(employee == null)
            {
                return NotFound();
            }
            _employeeContext.Employees.Remove(employee);
            await _employeeContext.SaveChangesAsync();
            return Ok();
        }
    }
}
