﻿namespace net_crud.Models
{
    public class Employee
    {
        public string id { get; set; }
        public string name { get; set; }
        public DateTime birthDate {  get; set; }  
        public int gender { get; set; }

    }
}
